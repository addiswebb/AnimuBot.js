const Discord = require('discord.js');

module.exports = {
  name: 'a',
  description: '',

  execute(message,arg){

    const fs = require('fs');
    //const anime = require('E:/GithubRepos/CrunchyBot.js/anime/animeInfo.js');
    //let animeInfo = new anime(message.channel);
    //animeInfo.apiRequest(arg);
    

  }
}